/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum LocalData {
    DATA_INICIO("01/01/0001"),
    DATA_TERMINO("02/01/0001");
    
    private String localData;

    private LocalData(String localData) {
        this.localData = localData;
    }

    public String getLocalData() {
        return localData;
    }
    
    
}
