/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Fisica pessoaFisica1 = new Fisica("45456", "78778", "20/04/1990", "Marts", "11 4002-8922");
        Juridica pessoajuridica1 = new Juridica("0001-232323", "758469123", "Marta LTDA", "71 95555-6666");
        
        //System.out.println("Pessoa física:");
        //System.out.println("CPF: " + pessoaFisica1.getCpf());
        //System.out.println("RG: " + pessoaFisica1.getRg());
        //System.out.println("Data de nascimento: " + pessoaFisica1.getDataNascimento());
        //System.out.println("Nome: " + pessoaFisica1.getNome());
        //System.out.println("Telefone: " + pessoaFisica1.getTelefone());
        
        //System.out.println("\nPessoa jurídica:");
        //System.out.println("CNPJ: " + pessoajuridica1.getCnpj());        
        //System.out.println("Inscrição estadual: " + pessoajuridica1.getInscricaoEstadual());        
        //System.out.println("Nome: " + pessoajuridica1.getNome());        
        //System.out.println("Telefone: " + pessoajuridica1.getTelefone());
        
        System.out.println(pessoaFisica1.toString());
        System.out.println(pessoajuridica1.toString());
        
    }
}
