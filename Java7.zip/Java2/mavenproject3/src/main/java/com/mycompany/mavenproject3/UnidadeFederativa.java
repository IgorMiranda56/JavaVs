package com.mycompany.mavenproject3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum UnidadeFederativa {
    BAHIA("Bahia", "BA"),
    SAO_PAULO("São Paulo", "SP"),
    RIO_DE_JANEIRO("Rio de janeiro", "RJ");
    
    private String nomeEstado;
    private String siglaNome;

    private UnidadeFederativa(String nomeEstado, String siglaNome) {
        this.nomeEstado = nomeEstado;
        this.siglaNome = siglaNome;
    }

    public String getNomeEstado() {
        return nomeEstado;
    }

    public String getSiglaNome() {
        return siglaNome;
    }
    
    
}
