/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("protocolo", Sexo.FEMININO, EstadoCivil.CASADO, "20/06/1990", "Marta", "71 9", "Marta@gmail.com",
            new Endereco("Avenida A", "12", "202", "111", "Salvador", UnidadeFederativa.BAHIA));
        PrestacaoServico prestacaoServico1 = new PrestacaoServico("01/01/0001", "01/01/0002", "888", "777", "Mrt LTDA", "11 9", "jose@gmail.com", 
            new Endereco("Avenida B", "99", "78", "666", "São paulo", UnidadeFederativa.SAO_PAULO));
                
        System.out.println(cliente1.toString());
        System.out.println(prestacaoServico1.toString());
        
        
    }
}
