package com.mycompany.mavenproject3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum EstadoCivil {
    SOLTEIRO("Solteiro"),
    CASADO("Casado"),
    SEPARADO("Separado"),
    DIVORCIADO("Divorciado"),
    VIUVO("Viúvo");
    
    private String estadoCivilMinusculo;

    private EstadoCivil(String estadoCivilMinusculo) {
        this.estadoCivilMinusculo = estadoCivilMinusculo;
    }

    public String getEstadoCivilMinusculo() {
        return estadoCivilMinusculo;
    }

    @Override
    public String toString() {
        return estadoCivilMinusculo;
    }
    
    
}
