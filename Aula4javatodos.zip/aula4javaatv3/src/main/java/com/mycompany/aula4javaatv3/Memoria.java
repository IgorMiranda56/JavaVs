package com.mycompany.aula4javaatv3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Memoria extends Produto {
    private String armazenamento;

    //Construtor
    public Memoria(String armazenamento, String marca, String modelo) {
        super(marca, modelo);
        this.armazenamento = armazenamento;
    }
    
    //Métodos acessores
    public String getArmazenamento() {
        return armazenamento;
    }

    public void setArmazenamento(String armazenamento) {
        this.armazenamento = armazenamento;
    }
    
    
}
