/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula4javaatv3;

/**
 *
 * @author aluno.den
 */
public class Principal {
//Primeiro uso de herança
    public static void main(String[] args) {
        Memoria memoria1 = new Memoria("8GB", "Corsair", "DDR4");
        Processador processador1 = new Processador("3.9GHZ", "AMD", "Ryzen 5 3500G");
        Placamae placamae1 = new Placamae("AM4", "GYGABITE", "a520-DSH2");
        DispositivosArmazenamento dispostivoArmazenamento1 = new DispositivosArmazenamento(" 1TB",
        "SATA3", "SEAGATE", "BARRACUDA");
        
        //Exibindo informações
        System.out.println("Mémoria marca: " + memoria1.getMarca());
        System.out.println("Mémoria modelo: " + memoria1.getModelo());
        System.out.println("Mémoria armazenamento: " + memoria1.getArmazenamento());
        
        System.out.println("\nPlaca de video marca: " + processador1.getMarca());
        System.out.println("Placa de video modelo: " + processador1.getModelo());
        System.out.println("Placa de video armazenamento: " + processador1.getFrequencia());
        
        System.out.println("\nMarca Placa de mãe: " + placamae1.getMarca());
        System.out.println("Modelo Placa de mãe: " + placamae1.getModelo());
        System.out.println("Soquete Placa de mãe: " + placamae1.getSoquete());
        
        System.out.println("\nMarca dispostivo armazenamento: " + dispostivoArmazenamento1.getMarca());
        System.out.println("Modelo dispostivo armazenamento: " + dispostivoArmazenamento1.getModelo());
        System.out.println("Quantidade dispostivo armazenamento: " + dispostivoArmazenamento1.getCapacidadeArmazenamento());
        System.out.println("Conexão dispostivo armazenamento: " + dispostivoArmazenamento1.getTipoConexao());
    }
}
