package com.mycompany.aula4javaatv3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Placamae extends Produto{
    private String soquete;

    //Construtor
    public Placamae(String soquete, String marca, String modelo) {
        super(marca, modelo);
        this.soquete = soquete;
    }
    
    //Métodos acessores
    public String getSoquete() {
        return soquete;
    }

    public void setSoquete(String soquete) {
        this.soquete = soquete;
    }
    
}
