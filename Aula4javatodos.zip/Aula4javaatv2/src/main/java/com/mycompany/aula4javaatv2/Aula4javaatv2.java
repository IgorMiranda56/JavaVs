/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula4javaatv2;

/**
 *
 * @author aluno.den
 */
public class Aula4javaatv2 {

    public static void main(String[] args) {
        Funcionario funcionario1 = new Funcionario("123659", "Ronaldo", "Rua 20", "71-32659877", "ronaldototal90@gmail.com",
        new ContaBancaria("Caixa", "0002", "22659-6", "Corrente", 356.30, 4230.0));
        
        Funcionario funcionario2 = new Funcionario("136587", "Dango", "Rua vish", "71-32659875", "dangobalango@gmail.com",
        new ContaBancaria("Banco do Brasil", "0023", "26362-8", "Poupança", 265.36, 5231.30));
        
        //Exibindo resultados
        System.out.println("\nCódigo 1º Funcionário: " + funcionario1.getCodigoFuncionario());
        System.out.println("Nome do 1º Funcionário: " + funcionario1.getNome());
        System.out.println("Endereço do 1º Funcionário: " + funcionario1.getEndereco());
        System.out.println("Telefone do 1º Funcionário: " + funcionario1.getTelefone());
        System.out.println("E-mail do 1º Funcionário: " + funcionario1.getEmail());
        System.out.println("Banco do 1º Funcionário: " + funcionario1.getContaBanco().getBanco());
        System.out.println("Agência do 1º Funcionário: " + funcionario1.getContaBanco().getAgencia());
        System.out.println("Número conta do 1º Funcionário: " + funcionario1.getContaBanco().getNumeroConta());
        System.out.println("Tipo conta do 1º Funcionário: " + funcionario1.getContaBanco().getTipodaConta());
        System.out.println("Saldo conta do 1º Funcionário: " + funcionario1.getContaBanco().getSaldoAtual());
        System.out.println("Limite conta do 1º Funcionário: " + funcionario1.getContaBanco().getLimiteDisponivel());
        
        System.out.println("\nCódigo 2º Funcionário: " + funcionario2.getCodigoFuncionario());
        System.out.println("Nome do 2º Funcionário: " + funcionario2.getNome());
        System.out.println("Endereço do 2º Funcionário: " + funcionario2.getEndereco());
        System.out.println("Telefone do 2º Funcionário: " + funcionario2.getTelefone());
        System.out.println("E-mail do 2º Funcionário: " + funcionario2.getEmail());
        System.out.println("Banco do 2º Funcionário: " + funcionario2.getContaBanco().getBanco());
        System.out.println("Agência do 2º Funcionário: " + funcionario2.getContaBanco().getAgencia());
        System.out.println("Número conta do 2º Funcionário: " + funcionario2.getContaBanco().getNumeroConta());
        System.out.println("Tipo conta do 2º Funcionário: " + funcionario2.getContaBanco().getTipodaConta());
        System.out.println("Saldo conta do 2º Funcionário: " + funcionario2.getContaBanco().getSaldoAtual());
        System.out.println("Limite conta do 2º Funcionário: " + funcionario2.getContaBanco().getLimiteDisponivel());
    }
}
