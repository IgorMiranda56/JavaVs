/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula4java;

/**
 *
 * @author aluno.den
 */
public class Aula4java {

    public static void main(String[] args) {
        Clientes cliente1 = new Clientes("Nestor", 51, "1365987879", "Rua peixoto, Dendezeiros", "71-32654987");
        Veiculos veiculo1 = new Veiculos("KJL69854", "Branco", 5, 35, 140, 1);
        
        //Exibindo dados
        System.out.println("Nome do cliente: " + cliente1.getNome());
        System.out.println("Idade do cliente: " + cliente1.getIdade());
        System.out.println("CPF do cliente: " + cliente1.getCPF());
        System.out.println("Endereço do cliente: " + cliente1.getEndereco());
        System.out.println("Telefone do cliente: " + cliente1.getTelefone());
        
        System.out.println("\nPlaca do veiculo: " + veiculo1.getPlaca());
        System.out.println("Cor do veiculo: " + veiculo1.getCor());
        System.out.println("Numero de passageiros do veiculo: " + veiculo1.getNumeroPassageiros());
        System.out.println("Capacidade de combustivel do veiculo: " + veiculo1.getCapacidadeTanque() + " litros");
        System.out.println("Velocidade máxima do veiculo: " + veiculo1.getVelocidadeMaxima() + " Kmh");
        System.out.println("Velocidade máxima do veiculo: " + veiculo1.getConsumoMedio() + " por litro" + " para cada 1km");
        
    }
}
