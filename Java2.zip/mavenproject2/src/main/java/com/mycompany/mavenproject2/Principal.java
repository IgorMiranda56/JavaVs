/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Motoboy motoboy = new Motoboy("123", "José", "321", "213", 50);
        Engenheiro engenheiro = new Engenheiro("456", "João", "654", "546", 2000);
        Medico medico = new Medico("789", "Marta", "987", "879", 5000);
        
        System.out.println(motoboy.toString());
        System.out.println(engenheiro.toString());
        System.out.println(medico.toString());
    }
}
