package com.mycompany.mavenproject3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public enum Sexo {
    MASCULINO("Masculino"),
    FEMINIMO("Feminino");
    
    private String minusculo;

    private Sexo(String minusculo) {
        this.minusculo = minusculo;
    }

    public String getMinusculo() {
        return minusculo;
    }
    
    
}
