package com.mycompany.mavenproject3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Juridica extends Pessoa{
    private String cnpj;
    private String inscricaoEstadual;
    private LocalData localData;
    private LocalData localData;
    private double valorContrato;

    public Juridica(String cnpj, String inscricaoEstadual, LocalData localData, LocalData localData, double valorContrato, int id, String nome, String telefone, Endereco endereco) {
        super(id, nome, telefone, endereco);
        this.cnpj = cnpj;
        this.inscricaoEstadual = inscricaoEstadual;
        this.localData = localData;
        this.localData = localData;
        this.valorContrato = valorContrato;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    public double getValorContrato() {
        return valorContrato;
    }

    public void setValorContrato(double valorContrato) {
        this.valorContrato = valorContrato;
    }

    @Override
    public String toString() {
        return "Juridica{" + 
                "cnpj=" + cnpj + 
                ", inscricaoEstadual=" + inscricaoEstadual + 
                ", localData=" + localData + 
                ", localData=" + localData + 
                ", valorContrato=" + valorContrato;
    }

    
}
