/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Fisica pessoaFisica1 = new Fisica(Sexo.FEMINIMO, cpf, rg, dataNascimento, 0, 0, nome, telefone, endereco) 
                new Endereco(logradouro, numero, complemento, cep, cidade, UnidadeFederativa.BAHIA);
        Juridica pessoaJuridica1 = new Juridica(cnpj, inscricaoEstadual, pessoaFisica1, args, 0, 0, nome, telefone, endereco)
                new Endereco(logradouro, numero, complemento, cep, cidade, UnidadeFederativa.BAHIA);
                
        System.out.println(pessoaFisica1.toString());
        System.out.println(pessoaJuridica1.toString());
        
        
        
        
       
    }
}
