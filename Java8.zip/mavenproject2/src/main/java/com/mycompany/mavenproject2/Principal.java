/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Soma soma = new Soma();
        Subtracao subtracao = new Subtracao();
        Multiplicacao multiplicacao = new Multiplicacao();
        Divisao divisao = new Divisao();
        
        System.out.println("Soma: " + soma.calcular(3, 3));
        System.out.println("Subtração:" + subtracao.calcular(3, 3));
        System.out.println("Multiplicação: " + multiplicacao.calcular(3, 3));
        System.out.println("Divisão: " + divisao.calcular(3, 3));
    }
}
