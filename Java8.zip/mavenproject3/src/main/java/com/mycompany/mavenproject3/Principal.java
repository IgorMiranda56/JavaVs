/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        
    }
}
