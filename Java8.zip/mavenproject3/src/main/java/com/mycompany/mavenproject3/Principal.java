/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Advogado advogado = new Advogado("Marta", "111", "222", 
                new Endereco("Avenida A", "55", "132", "999", "Salvador", UnidadeFederativa.BAHIA), Setor.MARKETIMG, Sexo.FEMININO, 2000, "22/03/1999");
        //Motorista motorista = new Motorista("João", "999", "798", 
                //new Endereco("Avenida B", "8", "7", "778", "Sao Paulo", UnidadeFederativa.SAO_PAULO), Setor.MARKETIMG, Sexo.MASCULINO, 0, "11/02.1888");
        //Gerente gerente = new Gerente(Bonificacao.GERENTE, "José", "558", "468", 
                //new Endereco("Avenida C", "44", "654", "378", "Rio de Janeiro", UnidadeFederativa.RIO_DE_JANEIRO), Setor.OPERACOES, Sexo.MASCULINO, 6000, "04/08/1976");
        //Diretor diretor = new Diretor(Bonificacao.DIRETOR, "Marcia", "94656", "374", 
                //new Endereco("Avenida D", "6874", "5465", "3715", "Camaçari", UnidadeFederativa.BAHIA), Setor.RECURSOS_HUMANOS, Sexo.FEMININO, 8000, "08/10/1950");
        
        System.out.println(advogado.toString());
    }
}
