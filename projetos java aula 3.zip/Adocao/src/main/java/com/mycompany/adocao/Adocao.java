/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adocao;

/**
 *
 * @author aluno.den
 */
public class Adocao {

    public static void main(String[] args) {
        Pets pet1 = new Pets("Lampreia", 6, "border", "media", "Golden");
        Pets pet2 = new Pets("Costela", 3, "salsicha", "Pequeno", "Pato");
        
        //Exibindo dados
        System.out.println("1º animal de estimação");
        System.out.println("Nome do pet: " + pet1.getNome());
        System.out.println("Idade do pet: " + pet1.getIdade());
        System.out.println("Raça do pet: " + pet1.getRaca());
        System.out.println("Porte do pet: " + pet1.getPorte());
        System.out.println("Alimentação do pet: " + pet1.getAlimentacao() + "\n");
        
        System.out.println("2º animal de estimação");
        System.out.println("Nome do pet: " + pet2.getNome());
        System.out.println("Idade do pet: " + pet2.getIdade());
        System.out.println("Raça do pet: " + pet2.getRaca());
        System.out.println("Porte do pet: " + pet2.getPorte());
        System.out.println("Alimentação do pet: " + pet2.getAlimentacao() + "\n");
    }
}
