package com.mycompany.livraria;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno.den
 */
public class Livro {
    private String titulo;
    private String autor;
    private int paginasNumero;
    private double preco;
    
    //Construtor
    public Livro(String titulo, String autor, int paginasNumero, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.paginasNumero = paginasNumero;
        this.preco = preco;
    
    }

    //Métodos acessores
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginasNumero() {
        return paginasNumero;
    }

    public void setPaginasNumero(int paginasNumero) {
        this.paginasNumero = paginasNumero;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
