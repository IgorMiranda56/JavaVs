/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.livraria;

/**
 *
 * @author aluno.den
 */
public class PrincipalLivraria {

    public static void main(String[] args) {
        //Instanciano objetos.
        Livro unidade1 = new Livro("Carregador de Caixa: A caixa mágica", "Pedro Pereira", 300, 35.90);
        Livro unidade2 = new Livro("Carregador de Caixa Baixa Renda", "Pedro Pereira", 350, 30);
        
        //Exbindo dados
        System.out.println("1º Livro Título: " + unidade1.getTitulo());
        System.out.println("1º Livro Autor: " + unidade1.getAutor());
        System.out.println("1º Livro Páginas: " + unidade1.getPaginasNumero());
        System.out.println("1º Livro Preço: " + unidade1.getPreco() + "\n");
        
        System.out.println("2º Livro Título: " + unidade2.getTitulo());
        System.out.println("2º Livro Autor: " + unidade2.getAutor());
        System.out.println("2º Livro Páginas: " + unidade2.getPaginasNumero());
        System.out.println("2º Livro Preço: " + unidade2.getPreco());
    }
}
