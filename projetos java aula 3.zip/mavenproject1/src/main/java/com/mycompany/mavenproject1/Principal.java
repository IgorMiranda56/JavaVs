/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        //Instaciano o objeto
        Clientes cliente = new Clientes("Nestor", 20);
        Funcionarios funcionario = new Funcionarios("Pedro", "Carregador de caixa", 1300);
        
        //Funções set
        //cliente.setNome("Nestor");
        //cliente.setIdade(20);
        
        System.out.println("Nome: " + cliente.getNome());
        System.out.println("Idade: " + cliente.getIdade());
        
        System.out.println("\nDados do funcionário");
        System.out.println("Nome: " + funcionario.getNome());
        System.out.println("Função: " + funcionario.getFuncao());
        System.out.println("Salário: " + funcionario.getSalario());
    }     
}
