/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Funcionarios funcionario1 = new Funcionarios("999999", "Marta", 1500, Setor.MARKETING, Sexo.FEMININO, 20);
        Funcionarios funcionario2 = new Funcionarios("888888", "José", 4000, Setor.FINANCEIRO, Sexo.MASCULINO, 37);
        
        System.out.println("Id: " + funcionario1.getId());
        System.out.println("Nome: " + funcionario1.getNome());
        System.out.println("Salário: " + funcionario1.getSalario());
        System.out.println("Setor: " + funcionario1.getSetor().getTextoSetor());
        System.out.println("Sexo: " + funcionario1.getSexo().getTexto());
        System.out.println("Idade: " + funcionario1.getIdade());
        
        System.out.println("\nId: " + funcionario2.getId());
        System.out.println("Nome: " + funcionario2.getNome());
        System.out.println("Salário: " + funcionario2.getSalario());
        System.out.println("Setor: " + funcionario2.getSetor().getTextoSetor());
        System.out.println("Sexo: " + funcionario2.getSexo().getTexto());
        System.out.println("Idade: " + funcionario2.getIdade());
        
    }
}
