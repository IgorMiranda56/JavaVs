/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

/**
 *
 * @author aluno.den
 */
public class Mavenproject3 {

    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa(123, "Marta", 20, "11 4002-8922", "mrt@gmail.com", Sexo.FEMININO, endereco);
        new Endereco("Avenida A", "214", "Ap", "44444-444", "Salvado", UnidadeFederativa.BAHIA);
        
        System.out.println("Id: " + pessoa1.getId());
        System.out.println("Nome: " + pessoa1.getNome());
        System.out.println("Idade: " + pessoa1.getIdade());
        System.out.println("Telefone: " + pessoa1.getTelefone());
        System.out.println("E-mail: " + pessoa1.getEmail());
        System.out.println("Sexo: " + pessoa1.getSexo());
        System.out.println("\nEndereço: " + pessoa1.getEndereco());
       
        
    }
}
