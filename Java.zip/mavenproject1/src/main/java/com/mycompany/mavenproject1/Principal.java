/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author aluno.den
 */
public class Principal {

    public static void main(String[] args) {
        Clientes cliente = new Clientes("Marta", Sexo.FEMININO);
        
        System.out.println("Nome: " + cliente.getNome());
        System.out.println("Sexo: " + cliente.getSexo());
    }
}
